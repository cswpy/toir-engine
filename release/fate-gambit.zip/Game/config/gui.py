import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog


class JSONEditorApp:
    def __init__(self, master):
        self.master = master
        self.master.title("JSON Viewer & Editor")

        # Menubar
        self.menubar = tk.Menu(self.master)
        file_menu = tk.Menu(self.menubar, tearoff=0)
        file_menu.add_command(label="Open Combination JSON",
                              command=self.load_combination_file)
        file_menu.add_command(label="Open Shop Items JSON",
                              command=self.load_shop_items_file)
        self.menubar.add_cascade(label="File", menu=file_menu)
        self.master.config(menu=self.menubar)

        # Variables to store file paths
        self.combination_filename = None
        self.shop_items_filename = None

        # Internal data
        self.combination_data = []
        self.shop_items_data = []

        self.notebook = ttk.Notebook(self.master)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Create frames for each JSON file
        self.combination_frame = ttk.Frame(self.notebook)
        self.shop_items_frame = ttk.Frame(self.notebook)

        self.notebook.add(self.combination_frame, text="Combination")
        self.notebook.add(self.shop_items_frame, text="Shop Items")

        self.setup_combination_tab()
        self.setup_shop_items_tab()

    def load_combination_file(self):
        filename = filedialog.askopenfilename(
            title="Select Combination JSON File",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            self.combination_filename = filename
            self.combination_data = self.load_json(filename)
            self.update_combination_list()
            # Clear fields
            self.comb_name_var.set("")
            self.comb_multiplier_var.set(0)
            self.comb_check_func_var.set("")
            messagebox.showinfo(
                "Loaded", f"Loaded combination file: {filename}")

    def load_shop_items_file(self):
        filename = filedialog.askopenfilename(
            title="Select Shop Items JSON File",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            self.shop_items_filename = filename
            self.shop_items_data = self.load_json(filename)
            self.update_shop_list()
            self.clear_shop_properties()
            messagebox.showinfo(
                "Loaded", f"Loaded shop items file: {filename}")

    def load_json(self, filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            messagebox.showerror("Error", f"Failed to load {filename}: {e}")
            return []

    # -----------------
    # Combination Tab
    # -----------------
    def setup_combination_tab(self):
        # Left side: List of combinations
        left_frame = ttk.Frame(self.combination_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)

        self.combination_listbox = tk.Listbox(left_frame, height=20, width=40)
        self.combination_listbox.pack(side=tk.TOP, fill=tk.Y)
        self.combination_listbox.bind(
            '<<ListboxSelect>>', self.on_combination_select)

        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=5)

        add_btn = ttk.Button(btn_frame, text="Add",
                             command=self.add_combination)
        add_btn.pack(side=tk.LEFT, padx=5)

        del_btn = ttk.Button(btn_frame, text="Delete",
                             command=self.delete_combination)
        del_btn.pack(side=tk.LEFT, padx=5)

        save_btn = ttk.Button(btn_frame, text="Save",
                              command=self.save_combination)
        save_btn.pack(side=tk.LEFT, padx=5)

        # Right side: Fields for editing
        right_frame = ttk.Frame(self.combination_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH,
                         expand=True, padx=5, pady=5)

        ttk.Label(right_frame, text="Name:").grid(
            row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.comb_name_var = tk.StringVar()
        self.comb_name_entry = ttk.Entry(
            right_frame, textvariable=self.comb_name_var)
        self.comb_name_entry.grid(
            row=0, column=1, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(right_frame, text="Multiplier:").grid(
            row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.comb_multiplier_var = tk.DoubleVar()
        self.comb_multiplier_entry = ttk.Entry(
            right_frame, textvariable=self.comb_multiplier_var)
        self.comb_multiplier_entry.grid(
            row=1, column=1, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(right_frame, text="Check Function:").grid(
            row=2, column=0, sticky=tk.W, padx=5, pady=5)
        self.comb_check_func_var = tk.StringVar()
        self.comb_check_func_entry = ttk.Entry(
            right_frame, textvariable=self.comb_check_func_var)
        self.comb_check_func_entry.grid(
            row=2, column=1, sticky=tk.EW, padx=5, pady=5)

        # Make columns expand properly
        right_frame.columnconfigure(1, weight=1)

    def update_combination_list(self):
        self.combination_listbox.delete(0, tk.END)
        for i, combo in enumerate(self.combination_data):
            self.combination_listbox.insert(tk.END, f"{i}: {combo['name']}")

    def on_combination_select(self, event):
        selection = self.combination_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.combination_data):
            combo = self.combination_data[index]
            self.comb_name_var.set(combo.get('name', ''))
            self.comb_multiplier_var.set(combo.get('multiplier', 0))
            self.comb_check_func_var.set(combo.get('checkFunction', ''))

    def add_combination(self):
        if not self.combination_filename:
            messagebox.showerror("Error", "No combination file loaded.")
            return
        new_entry = {
            "name": "New Combination",
            "multiplier": 1.0,
            "checkFunction": ""
        }
        self.combination_data.append(new_entry)
        self.update_combination_list()
        self.combination_listbox.selection_clear(0, tk.END)
        self.combination_listbox.selection_set(tk.END)
        self.on_combination_select(None)

    def delete_combination(self):
        if not self.combination_filename:
            messagebox.showerror("Error", "No combination file loaded.")
            return
        selection = self.combination_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.combination_data):
            del self.combination_data[index]
        self.update_combination_list()
        # Clear fields
        self.comb_name_var.set("")
        self.comb_multiplier_var.set(0)
        self.comb_check_func_var.set("")

    def save_combination(self):
        if not self.combination_filename:
            messagebox.showerror("Error", "No combination file loaded.")
            return
        # Update currently selected combination with fields
        selection = self.combination_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.combination_data):
                self.combination_data[index]['name'] = self.comb_name_var.get()
                self.combination_data[index]['multiplier'] = float(
                    self.comb_multiplier_var.get())
                self.combination_data[index]['checkFunction'] = self.comb_check_func_var.get(
                )

        # Write to file
        try:
            with open(self.combination_filename, 'w', encoding='utf-8') as f:
                json.dump(self.combination_data, f, indent=4)
            messagebox.showinfo(
                "Success", "Combination data saved successfully.")
            self.update_combination_list()
        except Exception as e:
            messagebox.showerror(
                "Error", f"Failed to save combination file: {e}")

    # -----------------
    # Shop Items Tab
    # -----------------

    def setup_shop_items_tab(self):
        # Known properties schema
        # Numeric properties
        self.num_properties = [
            ('increment_rerolls', int),
            ('increment_submissions', int),
            ('increment_score_multiplier', float),
            ('bonus_on_four', int),
            ('minimum_dice_value', int)
        ]
        # Boolean properties
        self.bool_properties = [
            'allow_revival',
            'persist_between_rounds',
            'is_consumable',
            'requires_boss_defeated',
            'carry_over_rerolls',
            'store_dice',
            'duplicate_before_reroll'
        ]

        # Left side: List of shop items
        left_frame = ttk.Frame(self.shop_items_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)

        self.shop_listbox = tk.Listbox(left_frame, height=20, width=40)
        self.shop_listbox.pack(side=tk.TOP, fill=tk.Y)
        self.shop_listbox.bind('<<ListboxSelect>>', self.on_shop_select)

        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=5)

        add_btn = ttk.Button(btn_frame, text="Add", command=self.add_shop_item)
        add_btn.pack(side=tk.LEFT, padx=5)

        del_btn = ttk.Button(btn_frame, text="Delete",
                             command=self.delete_shop_item)
        del_btn.pack(side=tk.LEFT, padx=5)

        save_btn = ttk.Button(btn_frame, text="Save",
                              command=self.save_shop_items)
        save_btn.pack(side=tk.LEFT, padx=5)

        # Right side: Fields for editing
        right_frame = ttk.Frame(self.shop_items_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH,
                         expand=True, padx=5, pady=5)

        ttk.Label(right_frame, text="ID:").grid(
            row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.shop_id_var = tk.StringVar()
        self.shop_id_entry = ttk.Entry(
            right_frame, textvariable=self.shop_id_var)
        self.shop_id_entry.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(right_frame, text="Name:").grid(
            row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.shop_name_var = tk.StringVar()
        self.shop_name_entry = ttk.Entry(
            right_frame, textvariable=self.shop_name_var)
        self.shop_name_entry.grid(
            row=1, column=1, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(right_frame, text="Cost:").grid(
            row=2, column=0, sticky=tk.W, padx=5, pady=5)
        self.shop_cost_var = tk.IntVar()
        self.shop_cost_entry = ttk.Entry(
            right_frame, textvariable=self.shop_cost_var)
        self.shop_cost_entry.grid(
            row=2, column=1, sticky=tk.EW, padx=5, pady=5)

        # Properties frame
        prop_frame = ttk.LabelFrame(right_frame, text="Properties")
        prop_frame.grid(row=3, column=0, columnspan=2,
                        sticky=tk.EW, padx=5, pady=5)
        prop_frame.columnconfigure(1, weight=1)

        # Numeric properties
        self.num_vars = {}
        row_idx = 0
        for prop_name, prop_type in self.num_properties:
            ttk.Label(prop_frame, text=prop_name+":").grid(row=row_idx,
                                                           column=0, sticky=tk.W, padx=5, pady=2)
            var = tk.StringVar()
            entry = ttk.Entry(prop_frame, textvariable=var)
            entry.grid(row=row_idx, column=1, sticky=tk.EW, padx=5, pady=2)
            self.num_vars[prop_name] = (var, prop_type)
            row_idx += 1

        # Boolean properties
        self.bool_vars = {}
        for prop_name in self.bool_properties:
            var = tk.BooleanVar()
            chk = ttk.Checkbutton(prop_frame, text=prop_name, variable=var)
            chk.grid(row=row_idx, column=0, columnspan=2,
                     sticky=tk.W, padx=5, pady=2)
            self.bool_vars[prop_name] = var
            row_idx += 1

        # dice_effects frame
        self.dice_effects_frame = ttk.LabelFrame(
            right_frame, text="Effects on Dice Roll")
        self.dice_effects_frame.grid(
            row=4, column=0, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        self.dice_effects_frame.columnconfigure(1, weight=1)

        self.dice_effects_listbox = tk.Listbox(
            self.dice_effects_frame, height=5, width=30)
        self.dice_effects_listbox.grid(
            row=0, column=0, rowspan=4, sticky=tk.NS, padx=5, pady=5)
        self.dice_effects_listbox.bind(
            '<<ListboxSelect>>', self.on_dice_effect_select)

        self.trigger_value_var = tk.StringVar()
        self.bonus_points_var = tk.StringVar()

        ttk.Label(self.dice_effects_frame, text="Trigger Value:").grid(
            row=0, column=1, sticky=tk.W, padx=5, pady=5)
        self.trigger_value_entry = ttk.Entry(
            self.dice_effects_frame, textvariable=self.trigger_value_var)
        self.trigger_value_entry.grid(
            row=0, column=2, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(self.dice_effects_frame, text="Bonus Points:").grid(
            row=1, column=1, sticky=tk.W, padx=5, pady=5)
        self.bonus_points_entry = ttk.Entry(
            self.dice_effects_frame, textvariable=self.bonus_points_var)
        self.bonus_points_entry.grid(
            row=1, column=2, sticky=tk.EW, padx=5, pady=5)

        dice_btn_frame = ttk.Frame(self.dice_effects_frame)
        dice_btn_frame.grid(row=2, column=1, columnspan=2,
                            sticky=tk.W, padx=5, pady=5)

        add_effect_btn = ttk.Button(
            dice_btn_frame, text="Add Effect", command=self.add_dice_effect)
        add_effect_btn.pack(side=tk.LEFT, padx=5)
        del_effect_btn = ttk.Button(
            dice_btn_frame, text="Delete Effect", command=self.delete_dice_effect)
        del_effect_btn.pack(side=tk.LEFT, padx=5)

        right_frame.columnconfigure(1, weight=1)

    def update_shop_list(self):
        self.shop_listbox.delete(0, tk.END)
        for i, item in enumerate(self.shop_items_data):
            self.shop_listbox.insert(tk.END, f"{i}: {item['name']}")

    def clear_shop_properties(self):
        # Clear all fields
        self.shop_id_var.set("")
        self.shop_name_var.set("")
        self.shop_cost_var.set(0)
        for prop_name, (var, _) in self.num_vars.items():
            var.set("")
        for prop_name in self.bool_vars:
            self.bool_vars[prop_name].set(False)
        self.clear_dice_effects()

    def on_shop_select(self, event):
        selection = self.shop_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.shop_items_data):
            item = self.shop_items_data[index]
            self.shop_id_var.set(item.get('id', ''))
            self.shop_name_var.set(item.get('name', ''))
            self.shop_cost_var.set(item.get('cost', 0))

            props = item.get('properties', {})
            # Set numeric properties
            for prop_name, (var, _) in self.num_vars.items():
                val = props.get(prop_name, 0)
                var.set(str(val))
            # Set boolean properties
            for prop_name, var in self.bool_vars.items():
                val = props.get(prop_name, False)
                var.set(bool(val))

            # Handle dice_effects if present
            self.load_dice_effects(props.get('dice_effects', None))

    def add_shop_item(self):
        if not self.shop_items_filename:
            messagebox.showerror("Error", "No shop items file loaded.")
            return
        new_item = {
            "id": "new_item",
            "name": "New Item",
            "cost": 0,
            "properties": {}
        }
        self.shop_items_data.append(new_item)
        self.update_shop_list()
        self.shop_listbox.selection_clear(0, tk.END)
        self.shop_listbox.selection_set(tk.END)
        self.on_shop_select(None)

    def delete_shop_item(self):
        if not self.shop_items_filename:
            messagebox.showerror("Error", "No shop items file loaded.")
            return
        selection = self.shop_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.shop_items_data):
            del self.shop_items_data[index]
        self.update_shop_list()
        self.clear_shop_properties()

    def save_shop_items(self):
        if not self.shop_items_filename:
            messagebox.showerror("Error", "No shop items file loaded.")
            return
        # Update currently selected item
        selection = self.shop_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.shop_items_data):
                # Validate numeric fields
                props = {}
                for prop_name, (var, prop_type) in self.num_vars.items():
                    val_str = var.get().strip()
                    if val_str == "":
                        val = 0
                    else:
                        try:
                            val = prop_type(val_str)
                        except ValueError:
                            messagebox.showerror(
                                "Error", f"Invalid value for {prop_name}.")
                            return
                    props[prop_name] = val

                # Booleans
                for prop_name, bvar in self.bool_vars.items():
                    props[prop_name] = bool(bvar.get())

                # dice_effects
                dice_effects = self.get_dice_effects_data()
                if dice_effects is not None:
                    props['dice_effects'] = dice_effects

                self.shop_items_data[index]['id'] = self.shop_id_var.get()
                self.shop_items_data[index]['name'] = self.shop_name_var.get()
                self.shop_items_data[index]['cost'] = self.shop_cost_var.get()
                self.shop_items_data[index]['properties'] = props

        # Save to file
        try:
            with open(self.shop_items_filename, 'w', encoding='utf-8') as f:
                json.dump(self.shop_items_data, f, indent=4)
            messagebox.showinfo(
                "Success", "Shop items data saved successfully.")
            self.update_shop_list()
        except Exception as e:
            messagebox.showerror(
                "Error", f"Failed to save shop items file: {e}")

    # Handling dice_effects
    def load_dice_effects(self, dice_effects):
        self.clear_dice_effects()
        if dice_effects is None:
            # No dice_effects property
            self.dice_effects = []
            return
        self.dice_effects = dice_effects[:]
        for i, eff in enumerate(self.dice_effects):
            self.dice_effects_listbox.insert(tk.END, f"Effect {i+1}")
        if self.dice_effects:
            self.dice_effects_listbox.selection_set(0)
            self.on_dice_effect_select(None)

    def clear_dice_effects(self):
        self.dice_effects_listbox.delete(0, tk.END)
        self.dice_effects = []
        self.trigger_value_var.set("")
        self.bonus_points_var.set("")

    def on_dice_effect_select(self, event):
        selection = self.dice_effects_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.dice_effects):
            eff = self.dice_effects[index]
            # assume keys 'trigger_value' and 'bonus_points' exist
            self.trigger_value_var.set(str(eff.get('trigger_value', 0)))
            self.bonus_points_var.set(str(eff.get('bonus_points', 0)))

    def add_dice_effect(self):
        new_effect = {"trigger_value": 0, "bonus_points": 0}
        self.dice_effects.append(new_effect)
        self.dice_effects_listbox.insert(
            tk.END, f"Effect {len(self.dice_effects)}")
        self.dice_effects_listbox.selection_clear(0, tk.END)
        self.dice_effects_listbox.selection_set(tk.END)
        self.on_dice_effect_select(None)

    def delete_dice_effect(self):
        selection = self.dice_effects_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        if index < len(self.dice_effects):
            del self.dice_effects[index]
        self.load_dice_effects(self.dice_effects)

    def get_dice_effects_data(self):
        # Update currently selected effect with fields
        selection = self.dice_effects_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.dice_effects):
                try:
                    trigger_val = int(self.trigger_value_var.get())
                    bonus_val = int(self.bonus_points_var.get())
                except ValueError:
                    messagebox.showerror(
                        "Error", "Trigger Value and Bonus Points must be integers.")
                    return None
                self.dice_effects[index]['trigger_value'] = trigger_val
                self.dice_effects[index]['bonus_points'] = bonus_val
        return self.dice_effects


if __name__ == "__main__":
    root = tk.Tk()
    app = JSONEditorApp(root)
    root.mainloop()
